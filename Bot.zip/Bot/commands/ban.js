exports.run = (client, message, args, Discord) => {
	// Tomar la primera mención del mensaje
  let member = message.mentions.members.first(); // Array / arreglo

  let memberUsername = member.tag; // Nombre#1234

	// Banear a '@'
  member.ban().then((member) => {
    // Notificar al servidor de que el usuario ha sido kickeado
    message.channel.send(memberUsername + ' ha sido banead@ del servidor.');
  });
};

/*
	var member = message.mentions.members.first();

    member.ban().then((member) => {
        // Success message
    });
 */
